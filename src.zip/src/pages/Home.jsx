import React from 'react'
import SideBar from '../components/SideBar'

const Home = () => {
  return (
    <div>
      <SideBar/>
    </div>
  )
}

export default Home

